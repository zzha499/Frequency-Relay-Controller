README.txt

Instructions for Running the Assignment on DE2-115 board
To start running our assignment on an Intel (Altera) DE2-115 development board if the provided project files do not work, please follow the steps below:

1. A .sof file is needed to program the device using Quartus Programmer tools.
2. Open NIOS build tools for Eclipse.
3. Create a new NIOS II application and BSP from Template using the provided nios2.sopcinfo and then select the Hello World template.
4. Replace all contents of the hello_world.c with our main.c.
5. Copy the provided FreeRTOS folder into the project directory folder.
6. Compile and Build the program.
7. Right click on the project folder and then select Run as NIOS II Hardware.

Load managing conditions are know to be unreliable. Comment out a return UNSTABLE statement in isNetworkStable()
to test the other condition.

PERIPHERALS USED:
This example exercises the following peripherals:
- STDOUT device (UART or JTAG UART)

SOFTWARE SOURCE FILES:
This example includes the following software source files:
- main.c

BOARD/HOST REQUIREMENTS:
This example requires only a JTAG connection with a Nios Development board. If
the host communication settings are changed from JTAG UART (default) to use a
conventional UART, a serial cable between board DB-9 connector  and the host is
required.
