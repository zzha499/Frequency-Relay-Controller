#include <stdio.h>
#include <unistd.h>
#include "system.h"

#include <altera_avalon_pio_regs.h>
#include <sys/alt_irq.h>
#include "sys/alt_alarm.h"
#include "altera_up_avalon_ps2.h"
#include "altera_up_ps2_keyboard.h"
#include "altera_up_avalon_video_character_buffer_with_dma.h"
#include "altera_up_avalon_video_pixel_buffer_dma.h"

#include "FreeRTOS/FreeRTOS.h"
#include "FreeRTOS/task.h"
#include "FreeRTOS/timers.h"
#include "FreeRTOS/queue.h"
#include "FreeRTOS/semphr.h"

//For frequency plot
#define FREQPLT_ORI_X 101		//x axis pixel position at the plot origin
#define FREQPLT_GRID_SIZE_X 5	//pixel separation in the x axis between two data points
#define FREQPLT_ORI_Y 199.0		//y axis pixel position at the plot origin
#define FREQPLT_FREQ_RES 20.0	//number of pixels per Hz (y axis scale)

#define ROCPLT_ORI_X 101
#define ROCPLT_GRID_SIZE_X 5
#define ROCPLT_ORI_Y 259.0
#define ROCPLT_ROC_RES 0.5		//number of pixels per Hz/s (y axis scale)

#define MIN_FREQ 45.0 //minimum frequency to draw

#define PRVGADraw_Task_P      (tskIDLE_PRIORITY+1)

static QueueHandle_t Q_freq_data;

typedef struct{
	unsigned int x1;
	unsigned int y1;
	unsigned int x2;
	unsigned int y2;
}Line;

#define NUM_LOADS 5
#define BUFFER_SIZE 2
#define SAMPLING_FREQUENCY 16000.0
#define SAMPLING_FREQ 16000.0

#define KEY_UP 0x75
#define KEY_DOWN 0x72
#define KEY_LEFT 0x6b
#define KEY_RIGHT 0x74

enum FREQUENCYSTATE{MONITORING_STATE, MANAGING_STATE};
enum MAINTENENCESTATE{ACTIVE,INACTIVE};
enum STABILITY{UNSTABLE,STABLE};

static void prvCalculateFrequencyTask(void *pvParameters);
static void prvMaintenanceModeTask(void *pvParameters);
static void prvChangeThresholdTask(void *pvParameters);
static void prvVGADisplayTask(void *pvParameters);

void vStabilityTimerCallback(TimerHandle_t timer);
void freq_analyser_isr(void* context, alt_u32 id);
void push_button_isr(void* context, alt_u32 id);
void keyboard_isr(void* context, alt_u32 id);
enum STABILITY isNetworkStable(unsigned int frequency_buffer[BUFFER_SIZE]);

int debounce = 0;
double frequency_threshold = 50;
double rate_of_change_threshold = 7.0;

static SemaphoreHandle_t xStabilityTimerSemaphore;
static SemaphoreHandle_t xMaintenanceSemaphore;
static SemaphoreHandle_t xKeyboardSemaphore;
static QueueHandle_t xFrequencyQueue;
static QueueHandle_t xKeyQueue;
static QueueHandle_t xResponseTimeQueue;
TimerHandle_t stability_timer;
TimerHandle_t tracking_timer;
int response_time_start;
int response_time;
FILE* lcd_fp;
static unsigned char esc = 0x1b;
enum STABILITY network_stability;

void vStabilityTimerCallback(TimerHandle_t timer) {
	xSemaphoreGiveFromISR(xStabilityTimerSemaphore, pdFALSE);
}

void freq_analyser_isr(void* context, alt_u32 id) {
	unsigned int temp_int = IORD(FREQUENCY_ANALYSER_BASE, 0);
	xQueueSendFromISR(xFrequencyQueue, &temp_int, pdFALSE);

	double temp_d = SAMPLING_FREQ/(double)IORD(FREQUENCY_ANALYSER_BASE, 0);
	xQueueSendToBackFromISR(Q_freq_data, &temp_d, pdFALSE);
}

void push_button_isr(void* context, alt_u32 id) {
	volatile int* edge_capture_ptr = (volatile int*) context;
	*edge_capture_ptr = IORD_ALTERA_AVALON_PIO_EDGE_CAP(PUSH_BUTTON_BASE);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PUSH_BUTTON_BASE, 0x7);

	xSemaphoreGiveFromISR(xMaintenanceSemaphore, pdFALSE);
}

void keyboard_isr(void *context, alt_u32 id) {
	char ascii;
	int status = 0;
	unsigned char key = 0;
	KB_CODE_TYPE decode_mode;
	status = decode_scancode (context, &decode_mode , &key , &ascii) ;

	if(status == 0) {
		if(debounce == 1) {
			debounce = 0;
			xQueueSendFromISR(xKeyQueue, &key, pdFALSE);
		} else {
			debounce = 1;
		}
	}
}

int main(void) {
	// Initialise Semaphores
	xStabilityTimerSemaphore = xSemaphoreCreateBinary();
	xMaintenanceSemaphore = xSemaphoreCreateBinary();
	xKeyboardSemaphore = xSemaphoreCreateBinary();

	// Initiialise Queues
	xFrequencyQueue = xQueueCreate(10, sizeof(unsigned int));
	xKeyQueue = xQueueCreate(10, sizeof(unsigned char));
	xResponseTimeQueue = xQueueCreate(5, sizeof(int));
	Q_freq_data = xQueueCreate(100, sizeof(double));

	// Start Calculate Frequency Task
	xTaskCreate(prvCalculateFrequencyTask,
				"Calculate Frequency",
				configMINIMAL_STACK_SIZE,
				NULL,
				1,
				NULL);

	// Start Maintenance Mode Task
	xTaskCreate(prvMaintenanceModeTask,
					"Maintenance Mode",
					configMINIMAL_STACK_SIZE,
					NULL,
					2,
					NULL);

	// Start Threshold Change Task
	xTaskCreate(prvChangeThresholdTask,
					"Change Threshold",
					configMINIMAL_STACK_SIZE,
					NULL,
					2,
					NULL);

	// Start VGA Task
	xTaskCreate(prvVGADisplayTask,
					"DrawTsk",
					configMINIMAL_STACK_SIZE,
					NULL,
					PRVGADraw_Task_P,
					NULL);

	// Create timer that monitors stability changes
	stability_timer = xTimerCreate("Stability Timer",
									pdMS_TO_TICKS(500),
									pdFALSE,
									(void*) 0,
									vStabilityTimerCallback);

	// Open the character LCD as a file stream for write
	lcd_fp = fopen(CHARACTER_LCD_NAME, "w");

	if(lcd_fp == NULL) {
		printf("LCD open failed\n");
		return 1;
	} else {
		fprintf(lcd_fp,"lcd init test");
	}

	// Clear all leds
	IOWR_ALTERA_AVALON_PIO_DATA(RED_LEDS_BASE, 0);
	IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, 0);

	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PUSH_BUTTON_BASE, 0x7);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PUSH_BUTTON_BASE, 0x7);

	// Register interrupts
	alt_irq_register(FREQUENCY_ANALYSER_IRQ, 0, freq_analyser_isr);
	alt_irq_register(PUSH_BUTTON_IRQ, 0, push_button_isr);

	alt_up_ps2_dev * ps2_device = alt_up_ps2_open_dev(PS2_NAME);
	alt_up_ps2_clear_fifo (ps2_device);
	alt_irq_register(PS2_IRQ, ps2_device, keyboard_isr);
	IOWR_8DIRECT(PS2_BASE,4,1);

	vTaskStartScheduler();

	return 0;
}

static void prvCalculateFrequencyTask(void *pvParameters) {
	unsigned int temp;
	enum FREQUENCYSTATE relay_state = MONITORING_STATE;
	int index = 0;
	unsigned int ADC_sample_buffer[BUFFER_SIZE];
	enum STABILITY new_network_stability;
	unsigned int loads = 0;
	int current_load;
	unsigned int switches;

	while(1) {
		switch(relay_state) {
			case MONITORING_STATE :
				// Perform maths on data
				// Only add to buffer if new data arrives
				if(xQueueReceive(xFrequencyQueue, &temp, 0) == pdPASS) {
					ADC_sample_buffer[index] = temp;
					index++;
					if(index == BUFFER_SIZE) {
						index = 0;
					}
				}
				// Update loads to reflect switches
				switches = IORD_ALTERA_AVALON_PIO_DATA(SLIDE_SWITCH_BASE);
				// Bit mask switches to only read first 5 switches
				loads = switches & ((1 << 4) | (1 << 3) | (1 << 2) | (1 << 1) | (1 << 0));
				IOWR_ALTERA_AVALON_PIO_DATA(RED_LEDS_BASE, loads);
				// Check if network is stable
				if(isNetworkStable(ADC_sample_buffer) == UNSTABLE) {
					// If network is not stable then enter Managing state
					network_stability = UNSTABLE;
					relay_state = MANAGING_STATE;
					response_time_start = (int)xTaskGetTickCount();
				}
				break;
			case MANAGING_STATE :
				// Turn off loads to stabilise network
				// Update switches
				// Only allowed to turn off, not on
				// switches bit values indicate only loads that can be on
				switches &= IORD_ALTERA_AVALON_PIO_DATA(SLIDE_SWITCH_BASE);

				// Shed or reconnect loads
				if(network_stability == STABLE) {
					// Turn on a load
					// Find highest priority load that is off
					// If load is off but switch has stayed on, turn on
					// Else go to next load and recheck condition
					current_load = 4;
					while(!((loads & (1 << current_load)) == 0 && (switches & (1 << current_load))) && current_load >= 0) {
						current_load--;
					}
					if(current_load < 0) {
						// All loads reconnected
						relay_state = MONITORING_STATE;
						IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, 0);
					} else {
						// Turn load on
						// Turn off corresponding green led
						loads |= (1 << current_load);
			        	unsigned int green_leds = IORD_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE);
			        	green_leds &= ~(1 << current_load);
			        	IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, green_leds);
					}
				} else {
					// Turn off a load
					// Loop through loads by priority
					// Find lowest priority that is on
					current_load = 0;
			        while((loads & (1 << current_load)) == 0 && current_load < 5) {
			        	current_load++;
			        }
					if(current_load == 0) {
						// First load shed - stop timer
						response_time = (int)xTaskGetTickCount() - response_time_start;
						xQueueSend(xResponseTimeQueue, &response_time, 0);
					}
			        if(current_load < 5) {
			        	// Turn off load only if one is on
			        	// Do nothing and wait for next 500ms if all off
			        	// Turn on corresponding green led
			        	loads &= ~(1 << current_load);
			        	unsigned int green_leds = IORD_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE);
			        	green_leds |= 1 << current_load;
			        	IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, green_leds);
			        }
				}

				// Update red leds to match loads
				IOWR_ALTERA_AVALON_PIO_DATA(RED_LEDS_BASE, loads);

				// Start monitoring for 500ms
				xTimerStart(stability_timer, 0);

				// Wait for timer to finish before shedding loads
				// Don't wait for semaphore - recalculate stability
				while(xSemaphoreTake(xStabilityTimerSemaphore, 0) == pdFALSE) {
					// Update loads with respect to switches
					// Allow user to turn off load but not on
					loads &= IORD_ALTERA_AVALON_PIO_DATA(SLIDE_SWITCH_BASE);
					IOWR_ALTERA_AVALON_PIO_DATA(RED_LEDS_BASE, loads);

					// Receive more data
					if(xQueueReceive(xFrequencyQueue, &temp, 0) == pdPASS) {
						ADC_sample_buffer[index] = temp;
						index++;
						if(index == BUFFER_SIZE) {
							index = 0;
						}
					}

					// Check if network stabilises or destabilises
					// Reset 500ms timer if stability changes
					new_network_stability = isNetworkStable(ADC_sample_buffer);
					if(network_stability != new_network_stability) {
						network_stability = new_network_stability;
						xTimerReset(stability_timer, 0);
					}
				}
				break;
			default:
				break;
		}
	}
}

enum STABILITY isNetworkStable(unsigned int ADC_sample_buffer[BUFFER_SIZE]) {
	// More maths - monitor frequency and calculate rate of change of frequency
	double frequency_buffer[BUFFER_SIZE];
	double rate_of_change_buffer[BUFFER_SIZE];

	// Condition 1 - Calculate under-frequency condition
	for(int i = 0;i < BUFFER_SIZE;i++) {
		frequency_buffer[i] = SAMPLING_FREQUENCY / (double)ADC_sample_buffer[i];
		if(frequency_buffer[i] < frequency_threshold) {
			// Comment out below to ignore condition
			return UNSTABLE;
		}
	}

	// Condition 2 - Calculate rate of change condition
	for(int i = 1;i < BUFFER_SIZE;i++) {
		double sample_average = (ADC_sample_buffer[i] + ADC_sample_buffer[i-1]) / 2.0;
		rate_of_change_buffer[i] = (frequency_buffer[i] - frequency_buffer[i-1]) * SAMPLING_FREQUENCY / sample_average;

		// Only interested in magnitude - ignore sign if negative
		if(rate_of_change_buffer[i] < 0) {
			rate_of_change_buffer[i] *= -1;
		}
		if(rate_of_change_buffer[i] > rate_of_change_threshold) {
			// Comment out below to ignore condition
			return UNSTABLE;
		}
	}
	return STABLE;
}

static void prvMaintenanceModeTask(void *pvParameters) {
	// Only switches control loads
	// Turn off all green leds
	// Set red leds to value of switches
	// Also change thresholds
	enum MAINTENENCESTATE state = INACTIVE;

	while(1) {
		if(state == ACTIVE) {
			// Implement Maintenance mode while waiting for semaphore
			fprintf(lcd_fp, "%c%sMaintenance Mode\n", esc, "[2J");
			while(xSemaphoreTake(xMaintenanceSemaphore, 0) == pdFALSE) {
				// Update leds
				IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, 0);
				unsigned int switches = IORD_ALTERA_AVALON_PIO_DATA(SLIDE_SWITCH_BASE);
				switches &= (1 << 4) | (1 << 3) | (1 << 2) | (1 << 1) | (1 << 0);
				IOWR_ALTERA_AVALON_PIO_DATA(RED_LEDS_BASE, switches);
			}
			state = INACTIVE;
			fprintf(lcd_fp, "%c%sMonitoring Mode\n", esc, "[2J");
		} else {
			// Keep waiting on semaphore even if max delay expires
			if(xSemaphoreTake(xMaintenanceSemaphore, portMAX_DELAY) == pdTRUE) {
				state = ACTIVE;
				// Green leds must be off in maintenance mode
				IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, 0);
			}
		}
	}
}

static void prvChangeThresholdTask(void *pvParameters) {
	unsigned char key;

	while(1) {
		// Receive key press value and change threshold
		xQueueReceive(xKeyQueue, &key, portMAX_DELAY);
		if(key == KEY_UP) {
			frequency_threshold += 0.1;
		} else if(key == KEY_DOWN) {
			frequency_threshold -= 0.1;
		} else if(key == KEY_LEFT) {
			rate_of_change_threshold -= 0.1;
		} else if(key == KEY_RIGHT) {
			rate_of_change_threshold += 0.1;
		}
		printf("frequency: %f\n", frequency_threshold);
		printf("roc: %f\n", rate_of_change_threshold);
	}
}

void prvVGADisplayTask(void *pvParameters){
	int response_buffer[5];
	int buffer_index = 0;

	//initialize VGA controllers
	alt_up_pixel_buffer_dma_dev *pixel_buf;
	pixel_buf = alt_up_pixel_buffer_dma_open_dev(VIDEO_PIXEL_BUFFER_DMA_NAME);
	if(pixel_buf == NULL){
		printf("can't find pixel buffer device\n");
	}
	alt_up_pixel_buffer_dma_clear_screen(pixel_buf, 0);

	alt_up_char_buffer_dev *char_buf;
	char_buf = alt_up_char_buffer_open_dev(	"/dev/video_character_buffer_with_dma");
	if(char_buf == NULL){
		printf("can't find char buffer device\n");
	}
	alt_up_char_buffer_clear(char_buf);

	//Set up plot axes
	alt_up_pixel_buffer_dma_draw_hline(pixel_buf, 100, 590, 200, ((0x3ff << 20) + (0x3ff << 10) + (0x3ff)), 0);
	alt_up_pixel_buffer_dma_draw_hline(pixel_buf, 100, 590, 300, ((0x3ff << 20) + (0x3ff << 10) + (0x3ff)), 0);
	alt_up_pixel_buffer_dma_draw_vline(pixel_buf, 100, 50, 200, ((0x3ff << 20) + (0x3ff << 10) + (0x3ff)), 0);
	alt_up_pixel_buffer_dma_draw_vline(pixel_buf, 100, 220, 300, ((0x3ff << 20) + (0x3ff << 10) + (0x3ff)), 0);

	alt_up_char_buffer_string(char_buf, "Frequency(Hz)", 4, 4);
	alt_up_char_buffer_string(char_buf, "52", 10, 7);
	alt_up_char_buffer_string(char_buf, "50", 10, 12);
	alt_up_char_buffer_string(char_buf, "48", 10, 17);
	alt_up_char_buffer_string(char_buf, "46", 10, 22);

	alt_up_char_buffer_string(char_buf, "df/dt(Hz/s)", 4, 26);
	alt_up_char_buffer_string(char_buf, "60", 10, 28);
	alt_up_char_buffer_string(char_buf, "30", 10, 30);
	alt_up_char_buffer_string(char_buf, "0", 10, 32);
	alt_up_char_buffer_string(char_buf, "-30", 9, 34);
	alt_up_char_buffer_string(char_buf, "-60", 9, 36);

	double freq[100], dfreq[100];
	int i = 99, j = 0;
	Line line_freq, line_roc;

	while(1) {
		// Print system response time
		char response_string[20];
		sprintf(response_string, "Response time: %d ms", response_time);
		alt_up_char_buffer_string(char_buf, response_string, 7, 44);

		// Print system uptime
		int uptime = (int)xTaskGetTickCount();
		char uptime_string[20];
		sprintf(uptime_string, "Total system uptime: %d ms", uptime);
		alt_up_char_buffer_string(char_buf, uptime_string, 7, 48);

		// Print system stability
		if(network_stability == STABLE) {
			alt_up_char_buffer_string(char_buf, "Stable  ", 7, 52);
		} else {
			alt_up_char_buffer_string(char_buf, "Unstable", 7, 52);
		}

		// Print last 5 time measurements
		alt_up_char_buffer_string(char_buf, "Last 5 measurements (ms):", 45, 42);
		if(xQueueReceive(xResponseTimeQueue, &(response_buffer[buffer_index]), 0) == pdTRUE) {
			if(buffer_index == 5) {
				buffer_index = 0;
			} else {
				buffer_index++;
			}
		}
		int max = 0;
		int min = 0;
		int sum = 0;
		for(int i = 0; i < 5; i++) {
			if(max < response_buffer[i]) {
				max = response_buffer[i];
			}
			if(min > response_buffer[i]) {
				min = response_buffer[i];
			}

			sum += response_buffer[i];

			char last_5_string;
			sprintf(last_5_string, "%d", response_buffer[i]);
			alt_up_char_buffer_string(char_buf, last_5_string, 45, 44 + i * 2);
		}

		// Print max and min
		char max_string;
		sprintf(max_string, "Max Time: %d ms", max);
		alt_up_char_buffer_string(char_buf, max_string, 45, 54);
		sprintf(max_string, "Min Time: %d ms              ", min);
		alt_up_char_buffer_string(char_buf, max_string, 45, 56);
		sprintf(max_string, "Average Time: %d ms          ", min);
		alt_up_char_buffer_string(char_buf, max_string, 7, 56);


		// Receive frequency data from queue
		while(uxQueueMessagesWaiting( Q_freq_data ) != 0){
			xQueueReceive( Q_freq_data, freq+i, 0 );

			//calculate frequency RoC

			if(i==0){
				dfreq[0] = (freq[0]-freq[99]) * 2.0 * freq[0] * freq[99] / (freq[0]+freq[99]);
			}
			else{
				dfreq[i] = (freq[i]-freq[i-1]) * 2.0 * freq[i]* freq[i-1] / (freq[i]+freq[i-1]);
			}

			if (dfreq[i] > 100.0){
				dfreq[i] = 100.0;
			}

			i =	(++i)%100; //point to the next data (oldest) to be overwritten

		}

		//clear old graph to draw new graph
		alt_up_pixel_buffer_dma_draw_box(pixel_buf, 101, 0, 639, 199, 0, 0);
		alt_up_pixel_buffer_dma_draw_box(pixel_buf, 101, 201, 639, 299, 0, 0);

		for(j=0;j<99;++j){ //i here points to the oldest data, j loops through all the data to be drawn on VGA
			if (((int)(freq[(i+j)%100]) > MIN_FREQ) && ((int)(freq[(i+j+1)%100]) > MIN_FREQ)){
				//Calculate coordinates of the two data points to draw a line in between
				//Frequency plot
				line_freq.x1 = FREQPLT_ORI_X + FREQPLT_GRID_SIZE_X * j;
				line_freq.y1 = (int)(FREQPLT_ORI_Y - FREQPLT_FREQ_RES * (freq[(i+j)%100] - MIN_FREQ));

				line_freq.x2 = FREQPLT_ORI_X + FREQPLT_GRID_SIZE_X * (j + 1);
				line_freq.y2 = (int)(FREQPLT_ORI_Y - FREQPLT_FREQ_RES * (freq[(i+j+1)%100] - MIN_FREQ));

				//Frequency RoC plot
				line_roc.x1 = ROCPLT_ORI_X + ROCPLT_GRID_SIZE_X * j;
				line_roc.y1 = (int)(ROCPLT_ORI_Y - ROCPLT_ROC_RES * dfreq[(i+j)%100]);

				line_roc.x2 = ROCPLT_ORI_X + ROCPLT_GRID_SIZE_X * (j + 1);
				line_roc.y2 = (int)(ROCPLT_ORI_Y - ROCPLT_ROC_RES * dfreq[(i+j+1)%100]);

				//Draw
				alt_up_pixel_buffer_dma_draw_line(pixel_buf, line_freq.x1, line_freq.y1, line_freq.x2, line_freq.y2, 0x3ff << 0, 0);
				alt_up_pixel_buffer_dma_draw_line(pixel_buf, line_roc.x1, line_roc.y1, line_roc.x2, line_roc.y2, 0x3ff << 0, 0);
			}
		}
		vTaskDelay(10);
	}
}
